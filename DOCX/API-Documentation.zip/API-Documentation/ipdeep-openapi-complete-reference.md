# IPDEEP OpenAPI 完整接口文档

**文档来源**: https://user.ipdeep.cn/api-doc
**抓取日期**: 2026-06-14
**API版本**: V1
**抓取方式**: Playwright 自动化抓取（1:1复现）
**重要修订**: 2026-06-15 根据 IPDEEP 官方反馈补充签名与 AES 实现细节，并已通过本地代理 `127.0.0.1:7897` 实测验证。

---

## ⚠️ 重要避坑声明：签名与 AES 规则必须按官方实现

> 这一节是实测后补充的关键信息。原网页文档只写了 `OpenApiSignHelper.GenerateSign(parameters, key)` 和 `AES-CBC`，没有展开实现，容易误判为 `MD5`、`API Secret 签名`、`随机 IV + IV 前置密文`。这些都是错的。

### ✅ 正确签名规则

签名算法不是 MD5，而是：

```text
HMAC-SHA256(query, API_KEY).hex_lowercase
```

关键点：

1. 参与签名的字段来自顶层请求字段：`key`, `timestamp`, `nonce`, `data`, `language`。
2. `sign` 不参与签名。
3. **过滤 value 为空的字段**：`null`、空字符串不参与签名。
4. 按字段名升序排序。
5. 拼接格式是 `key=value&key=value`。
6. HMAC-SHA256 的密钥是 **API Key**，不是 API Secret。
7. 输出为小写十六进制字符串。
8. 官方示例中 `nonce` 使用无横线 GUID：`Guid.NewGuid().ToString("N")`。普通 GUID 可能也被接受，但建议按官方实现使用无横线格式。
9. 官方示例中 `language = "zh"`。

Python 等价实现：

```python
import hmac
import hashlib

def generate_sign(parameters: dict, api_key: str) -> str:
    sign_params = {
        k: str(v)
        for k, v in parameters.items()
        if k != "sign" and v is not None and str(v) != ""
    }
    query = "&".join(f"{k}={v}" for k, v in sorted(sign_params.items()))
    return hmac.new(api_key.encode("utf-8"), query.encode("utf-8"), hashlib.sha256).hexdigest()
```

C# 官方核心实现：

```csharp
public static string GenerateSign(Dictionary<string, string> parameters, string secret)
{
    var sorted = parameters
        .Where(x => !string.IsNullOrEmpty(x.Value))
        .OrderBy(x => x.Key);

    var query = string.Join("&", sorted.Select(x => $"{x.Key}={x.Value}"));

    using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret));
    var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(query));

    return Convert.ToHexString(hash).ToLower();
}
```

调用时第二个参数传：

```csharp
request.sign = OpenApiSignHelper.GenerateSign(signParams, ApiKey);
```

不是 `ApiSecret`。

### ✅ 正确 AES-CBC 规则

AES 也不是随机 IV。官方实现是：

```text
aesSource = API_KEY + API_SECRET
aesKey = SHA256(aesSource).hexdigest().Substring(0, 32)
iv = aesKey.Substring(0, 16)
data = Base64(AES-CBC-PKCS7(json, aesKey, iv))
```

关键点：

1. AES key 是 `SHA256(API_KEY + API_SECRET)` 的十六进制字符串前 32 个字符。
2. AES key 作为 UTF-8 字符串转 bytes 使用，长度 32 bytes。
3. IV 固定取 `aesKey` 前 16 个字符，作为 UTF-8 bytes。
4. Padding 是 PKCS7（等同 Java 常说的 PKCS5Padding）。
5. Base64 内容只包含密文，不包含 IV。
6. **不要使用随机 IV**。
7. **不要把 IV 拼到密文前面再 Base64**。

Python 等价实现：

```python
import base64
import hashlib
import json
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

def aes_key(api_key: str, api_secret: str) -> str:
    return hashlib.sha256((api_key + api_secret).encode("utf-8")).hexdigest()[:32]

def encrypt_json(obj: dict, api_key: str, api_secret: str) -> str:
    key = aes_key(api_key, api_secret)
    iv = key[:16].encode("utf-8")
    plain = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    cipher = AES.new(key.encode("utf-8"), AES.MODE_CBC, iv=iv)
    return base64.b64encode(cipher.encrypt(pad(plain, AES.block_size))).decode("utf-8")

def decrypt_data(encrypted: str, api_key: str, api_secret: str) -> str:
    key = aes_key(api_key, api_secret)
    iv = key[:16].encode("utf-8")
    cipher = AES.new(key.encode("utf-8"), AES.MODE_CBC, iv=iv)
    return unpad(cipher.decrypt(base64.b64decode(encrypted)), AES.block_size).decode("utf-8")
```

### ✅ 无业务参数接口的请求形态

例如 `Account/balance` 没有业务参数时，官方实现中 `data` 为 `null`，但签名参数里用空字符串并被过滤：

```json
{
  "key": "<API_KEY>",
  "timestamp": 1781495967560,
  "nonce": "ec99da39a3f84149bdf9d5c3581bd5e8",
  "data": null,
  "language": "zh",
  "sign": "<hmac-sha256-lower>"
}
```

对应签名原文示例：

```text
key=<API_KEY>&language=zh&nonce=ec99da39a3f84149bdf9d5c3581bd5e8&timestamp=1781495967560
```

### ✅ 已实测通过的接口

使用本地前置代理 `127.0.0.1:7897`、出口 IP 加入白名单后，以下接口已验证成功：

- `Account/balance`：成功返回并解密为 `{"USD":0.0}`。
- `Account/traffic`：成功返回并解密剩余流量。
- `DynamicProxy/countries`：成功返回国家列表。
- `DynamicProxy/states`：成功返回美国州列表。
- `Whitelist/list`：成功返回白名单列表。

### ❌ 已确认错误的常见猜法

以下实现会导致 `10006 Sign Is Invalid`：

- `MD5(sorted_values + API_SECRET)`
- `MD5(key=value&... + API_SECRET)`
- `HMAC-SHA256(query, API_SECRET)`
- 随机 IV AES-CBC
- `Base64(IV + ciphertext)`

---

## 📋 目录

- [概述](#概述)
- [用户账户](#用户账户)
  - [账户余额](#账户余额)
  - [剩余流量](#剩余流量)
- [动态代理](#动态代理)
  - [获取可用国家](#获取可用国家)
  - [获取可用省份/州](#获取可用省份州)
  - [获取可用城市](#获取可用城市)
  - [修改动密码](#修改动密码)
- [静态代理](#静态代理)
  - [获取套餐](#获取套餐)
  - [获取产品](#获取产品)
  - [获取区域](#获取区域)
  - [获取IP列表](#获取ip列表)
  - [获取IP信息](#获取ip信息)
  - [修改静态IP密码](#修改静态ip密码)
- [订单](#订单)
  - [创建订单](#创建订单)
  - [创建续费订单](#创建续费订单)
  - [获取订单详情](#获取订单详情)
  - [获取订单列表](#获取订单列表)
- [白名单](#白名单)
  - [IP白名单列表](#ip白名单列表)
  - [添加白名单](#添加白名单)
  - [删除白名单](#删除白名单)

---

## 概述

所有OpenAPI端点均采用统一的请求结构 `OpenApiRequest<T>`

### 请求验证规则

1. `key` 必须是有效的 API 密钥
2. `timestamp` 必须在服务器时间 5 分钟内 (毫秒级时间戳)
3. `nonce` 随机字符串 / GUID 五分钟内不可重复使用
4. `sign` 必须于服务器签名匹配, 否则验证不通过
5. `data` 必须是 AES 加密后的 Base64 文本字符串

### 签名规则

> 详细实现见文档开头“重要避坑声明”。这里仅保留摘要，避免误解。

1. 读取顶级 JSON 字段中的 `key`, `timestamp`, `nonce`, `data`, `language`
2. 排除 `sign`
3. 过滤 value 为空的字段（例如 `data` 为 `null` / 空字符串时不参与签名）
4. 按字段名升序排序
5. 拼接为 `key=value&key=value` 格式
6. 使用 **API Key** 作为 HMAC 密钥生成 `HMAC-SHA256`
7. 输出小写十六进制字符串作为 `sign`

```text
sign = HMAC_SHA256_HEX_LOWER(query, API_KEY)
```

注意：不是 MD5，也不是用 API Secret 签名。

### 数据加密规则

> 详细实现见文档开头“重要避坑声明”。这里仅保留摘要，避免误解。

1. 将业务参数序列化为紧凑 JSON 字符串
2. 构建源字符串：`aesSource = API_KEY + API_SECRET`
3. 生成 AES 密钥：`aesKey = SHA256(aesSource).Substring(0, 32)`，这里的 SHA256 是十六进制字符串
4. AES key 使用 `aesKey` 的 UTF-8 bytes
5. IV 固定取 `aesKey.Substring(0, 16)` 的 UTF-8 bytes
6. 使用 AES-CBC + PKCS7 加密 JSON
7. 将密文直接 Base64 后绑定到 `data`

注意：不要使用随机 IV，不要将 IV 拼接到密文前面。

### 请求方式

**POST**

```
https://openapi.ipdeep.com/openApi/V1/{Controller}/{Action}
```

### 通用请求参数

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| key | API Key | string | Yes |
| timestamp | 必须在服务器时间 5 分钟内 (毫秒级时间戳) | long | Yes |
| nonce | 随机字符串 / GUID 五分钟内不可重复使用 | string | Yes |
| sign | 签名由除签名外的所有顶级字段生成 | string | Yes |
| data | 必须是 AES 加密后的 Base64 文本字符串 | string | No |
| language | Language | string | No |

### Example Request

```json
{
  "key": "demo_key",
  "timestamp": 1710000000000,
  "nonce": "3f4a5b6c7d8e9f0a",
  "data": "U2FsdGVkX19EncryptedBase64...",
  "language": "en",
  "sign": "1ba75a9f7e5bea0cc06ca732f163630b"
}
```

### 通用响应结构

All interfaces return JSON with: `ErrCode` / `ErrMsg` / `Success` / `ResData`

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| ErrCode | 状态码 | string |
| ErrMsg | 消息 | string |
| Success | 执行结果 | bool |
| ResData | 返回值 | object/string |

### 错误码

| Code | Explain |
|------|---------|
| 0 | 成功 |
| 10001 | 请求正文无效(body无效) |
| 10004 | 时间戳已过期 |
| 10005 | 重复请求 |
| 10006 | 签名无效 |
| 10007 | 请求频率超限 |
| 10008 | 帐户信息不存在或已过期/解密失败 |
| 40007 | 参数错误 |
| 401 | 用户信息无效 |
| 60001 | 未找到数据 |
| 20001 | 余额不足 |
| 1 | 重复添加 |
| 2 | 重复添加 |

---

## 用户账户

### 账户余额

**功能描述**: 获取账户余额

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Account/balance
```

**请求参数**: 无请求参数

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| USD | USD balance | decimal |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 剩余流量

**功能描述**: 获取账户剩余流量

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Account/traffic
```

**请求参数**: 无请求参数

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| UsedTraffic | 已使用流量 | string |
| TotalTraffic | 总流量 | string |
| RemainingTraffic | 剩余流量 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

## 动态代理

### 获取可用国家

**功能描述**: 按照代理类型获取动态代理支持的国家

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/DynamicProxy/countries
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| ProxyType | 参数必须为 dynamicDataCenter / dynamicResidential / mobile | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | 国家ID | long |
| Name | 国家名称 | string |
| Code | 国家代码 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 获取可用省份/州

**功能描述**: 按照代理类型和国家代码获取动态代理支持的省份/州

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/DynamicProxy/states
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| ProxyType | 参数必须为 dynamicDataCenter / dynamicResidential / mobile | string | Yes |
| CountryCode | 国家代码 | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | 省份ID | long |
| Name | 省份名称 | string |
| Code | 省份代码 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 获取可用城市

**功能描述**: 按照代理类型、国家代码和省份代码获取动态代理支持的城市

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/DynamicProxy/cities
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| ProxyType | 参数必须为 dynamicDataCenter / dynamicResidential / mobile | string | Yes |
| CountryCode | 国家代码 | string | Yes |
| StateCode | 省份代码 | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | 城市ID | long |
| Name | 城市名称 | string |
| Code | 城市代码 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 修改动密码

**功能描述**: 修改动态代理密码

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/DynamicProxy/updatePassword
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| NewPassword | 新密码 | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Success | 是否成功 | bool |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

## 静态代理

### 获取套餐

**功能描述**: 获取静态代理套餐列表

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/StaticProxy/packages
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| ProxyType | 参数必须为 staticResidential / staticDataCenter | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | 套餐ID | long |
| Name | 套餐名称 | string |
| Price | 价格 | decimal |
| Duration | 时长 | int |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 获取产品

**功能描述**: 获取静态代理产品列表

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/StaticProxy/products
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| ProxyType | 参数必须为 staticResidential / staticDataCenter | string | Yes |
| PackageId | 套餐ID | long | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | 产品ID | long |
| Name | 产品名称 | string |
| Description | 描述 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 获取区域

**功能描述**: 获取静态代理可用区域

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/StaticProxy/areas
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| ProxyType | 参数必须为 staticResidential / staticDataCenter | string | Yes |
| CountryCode | 国家代码 | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| AreaCode | 区域代码 | string |
| AreaName | 区域名称 | string |
| CountryCode | 国家代码 | string |
| StateCode | 省份代码 | string |
| CityCode | 城市代码 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 获取IP列表

**功能描述**: 获取静态代理IP列表

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/StaticProxy/ips
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| CurrenetPageIndex | 当前页 1 | int | Yes |
| PageSize | 每页显示数量 10 | int | Yes |
| Sort | 升序/降序 asc / desc | string | No |
| Order | 排序字段 | string | No |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| CurrentPage | 当前页 | int |
| ItemsPerPage | 每页数量 | int |
| TotalItems | 总条数 | int |
| Items | 数据列表 | array |

Items Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | IP ID | long |
| Ip | IP地址 | string |
| Port | 端口 | int |
| Protocol | 协议 | string |
| ExpireTime | 过期时间 | datetime |
| Status | 状态 | int |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 获取IP信息

**功能描述**: 获取单个静态代理IP详细信息

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/StaticProxy/ipInfo
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| IpId | IP ID | long | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | IP ID | long |
| Ip | IP地址 | string |
| Port | 端口 | int |
| Protocol | 协议 | string |
| Username | 用户名 | string |
| Password | 密码 | string |
| ExpireTime | 过期时间 | datetime |
| Status | 状态 | int |
| CountryCode | 国家代码 | string |
| StateCode | 省份代码 | string |
| CityCode | 城市代码 | string |
| Remark | 备注 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 修改静态IP密码

**功能描述**: 修改静态代理IP密码

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/StaticProxy/updatePassword
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| IpId | IP ID | long | Yes |
| NewPassword | 新密码 | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Success | 是否成功 | bool |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

## 订单

### 创建订单

**功能描述**: 创建静态代理IP订单

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Order/create
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| ProxyType | 代理类型 参数必须为 staticResidential / staticDataCenter | string | Yes |
| PackageId | 套餐ID | long | Yes |
| Count | 开通数量 | int | Yes |
| ReqOrderNo | 业务单编号 | string | Yes |
| AreaCode | 洲代码 | string | Yes |
| CountryCode | 国家代码 | string | Yes |
| CityCode | 城市代码 | string | Yes |
| Protocol | 网络协议 参数必须为 socks5 / http / mixed | string | No |
| IsAutoRenew | 自动续费 0 否, 1 是 | int | No |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| OrderNo | 我方订单编号 | string |
| ReqOrderNo | 业务单编编号 | string |
| OrderStatus | 订单状态 | int |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 创建续费订单

**功能描述**: 为现有的静态代理IP创建续费订单

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Order/renew
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| IpId | IP ID | long | Yes |
| PackageId | 套餐ID | long | Yes |
| ReqOrderNo | 业务单编号 | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| OrderNo | 我方订单编号 | string |
| ReqOrderNo | 业务单编编号 | string |
| OrderStatus | 订单状态 | int |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 获取订单详情

**功能描述**: 获取订单详细信息

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Order/detail
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| OrderNo | 订单编号 | string | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| OrderNo | 订单编号 | string |
| ReqOrderNo | 业务单编号 | string |
| OrderStatus | 订单状态 | int |
| ProxyType | 代理类型 | string |
| PackageId | 套餐ID | long |
| Count | 数量 | int |
| Amount | 金额 | decimal |
| CreateTime | 创建时间 | datetime |
| ExpireTime | 过期时间 | datetime |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 获取订单列表

**功能描述**: 获取订单分页列表

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Order/list
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| CurrenetPageIndex | 当前页 1 | int | Yes |
| PageSize | 每页显示数量 10 | int | Yes |
| Sort | 升序/降序 asc / desc | string | No |
| Order | 排序字段 CreatorTime | string | No |
| Filter | 筛选字段 | object | No |

Filter 参数

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| OrderNo | 订单编号 | string | No |
| OrderStatus | 订单状态 | int | No |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| CurrentPage | 当前页 | int |
| ItemsPerPage | 每页数量 | int |
| TotalItems | 总条数 | int |
| Items | 数据列表 | array |

Items Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| OrderNo | 订单编号 | string |
| ReqOrderNo | 业务单编号 | string |
| OrderStatus | 订单状态 | int |
| ProxyType | 代理类型 | string |
| Amount | 金额 | decimal |
| CreateTime | 创建时间 | datetime |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

## 白名单

### IP白名单列表

**功能描述**: 获取IP白名单分页列表

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Whitelist/list
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| CurrenetPageIndex | 当前页 1 | int | Yes |
| PageSize | 每页显示数量 10 | int | Yes |
| Sort | 升序/降序 asc / desc | string | No |
| Order | 排序字段 CreatorTime | string | No |
| Filter | 筛选字段 | object | No |

Filter 参数

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| Ip | 白名单IP | string | No |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| CurrentPage | 当前页 | int |
| ItemsPerPage | 每页数量 | int |
| TotalItems | 总条数 | int |
| Items | 数据列表 | array |

Items Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | 白名单ID | long |
| Ip | IP地址 | string |
| Remark | 备注 | string |
| CreatorTime | 套餐名称 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 添加白名单

**功能描述**: 添加IP到白名单

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Whitelist/add
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| Ip | IP地址 | string | Yes |
| Remark | 备注 | string | No |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Id | 白名单ID | long |
| Ip | IP地址 | string |
| Remark | 备注 | string |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

### 删除白名单

**功能描述**: 从白名单删除IP

**调用地址**

```
POST https://openapi.ipdeep.com/openApi/V1/Whitelist/delete
```

**请求参数**

| 字段 | 字段说明 | 字段类型 | 是否必填 |
|------|---------|---------|---------|
| Id | 白名单ID | long | Yes |

**响应结果**

结果数据 Info

| 字段 | 字段说明 | 字段类型 |
|------|---------|---------|
| Success | 是否成功 | bool |

**Example**

```json
{
  "ErrCode": "0",
  "ErrMsg": "success",
  "Success": true,
  "ResData": "encrypted_result"
}
```

---

## 附录

### API 端点汇总

| 模块 | 端点 | 功能 |
|------|------|------|
| 用户账户 | /Account/balance | 获取账户余额 |
| 用户账户 | /Account/traffic | 获取剩余流量 |
| 动态代理 | /DynamicProxy/countries | 获取可用国家 |
| 动态代理 | /DynamicProxy/states | 获取可用省份/州 |
| 动态代理 | /DynamicProxy/cities | 获取可用城市 |
| 动态代理 | /DynamicProxy/updatePassword | 修改动密码 |
| 静态代理 | /StaticProxy/packages | 获取套餐 |
| 静态代理 | /StaticProxy/products | 获取产品 |
| 静态代理 | /StaticProxy/areas | 获取区域 |
| 静态代理 | /StaticProxy/ips | 获取IP列表 |
| 静态代理 | /StaticProxy/ipInfo | 获取IP信息 |
| 静态代理 | /StaticProxy/updatePassword | 修改静态IP密码 |
| 订单 | /Order/create | 创建订单 |
| 订单 | /Order/renew | 创建续费订单 |
| 订单 | /Order/detail | 获取订单详情 |
| 订单 | /Order/list | 获取订单列表 |
| 白名单 | /Whitelist/list | IP白名单列表 |
| 白名单 | /Whitelist/add | 添加白名单 |
| 白名单 | /Whitelist/delete | 删除白名单 |

### 请求流程示例

```python
import requests
import json
import hashlib
import time
import uuid
from Crypto.Cipher import AES
import base64

# 1. 准备参数
api_key = "your_api_key"
api_secret = "your_api_secret"
timestamp = int(time.time() * 1000)
nonce = str(uuid.uuid4())

# 2. 加密业务数据
business_data = {"ProxyType": "dynamicResidential"}
data_json = json.dumps(business_data)
aes_source = api_key + api_secret
aes_key = hashlib.sha256(aes_source.encode()).hexdigest()[:32]

# AES-CBC 加密（需要实现）
# encrypted_data = aes_cbc_encrypt(data_json, aes_key)
# data = base64.b64encode(encrypted_data).decode()

# 3. 生成签名
params = {
    "key": api_key,
    "timestamp": timestamp,
    "nonce": nonce,
    "data": data,  # Base64 encoded encrypted data
    "language": "en"
}
# sign = generate_sign(params, api_key)

# 4. 发送请求
response = requests.post(
    "https://openapi.ipdeep.com/openApi/V1/DynamicProxy/countries",
    json=params
)
result = response.json()
```

---

**文档状态**: 完整抓取（19个API端点）
**抓取工具**: Playwright (headless Chromium)
**抓取时间**: 2026-06-14 16:17:00
